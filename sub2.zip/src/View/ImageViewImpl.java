package View;

import java.io.OutputStream;
import java.io.PrintStream;

/**
 * Given class will contain the methods implemented
 * for user interaction.
 * It displays output when exception occurs.
 * <p>
 * It will further pass command to controller for handling it.
 * </p>
 */
public class ImageViewImpl implements ImageView {

  @Override
  public void displayOutput(OutputStream out, String output) {
    PrintStream outStream = new PrintStream(out);
    outStream.println(output.trim());
  }
}
