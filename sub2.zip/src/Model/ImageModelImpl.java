package Model;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Utils.ImageUtilsImpl;

/**
 * Given implementation represents a model class.
 * It contains all the business logic of image processing and manipulation.
 * <p>
 * Given Image model class will contains various image processing logics
 * like load, save image, flip an image, convert it to greyscale image
 * based on various value components, combine and  split image etc.
 * </p>
 * Also, it will use generalised methods from the abstract class.
 */
public class ImageModelImpl implements ImageModel {

  private final Map<String, Image> imageCollection;
  ImageUtilsImpl imageUtilsImpl = new ImageUtilsImpl();
  private Image img;

  /**
   * Given constructor will initialize image collection hashmap
   * and error logs string builder.
   */
  public ImageModelImpl() {
    imageCollection = new HashMap<>();
  }

  @Override
  public void load(String path, String fileName) throws FileNotFoundException, IllegalArgumentException {
    this.img = imageUtilsImpl.readPPMImage(path);
    imageCollection.put(fileName, img);
  }

  @Override
  public void save(String path, String fileName) throws IOException {
    img.saveImage(path, imageCollection.get(fileName));
  }

  @Override
  public void visualizeComponent(COMPONENTS component, String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().visualizeComponent(component);
    imageCollection.put(destFileName, image);
  }

  @Override
  public void flipHorizontally(String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().flipHorizontally();
    imageCollection.put(destFileName, image);
  }

  @Override
  public void flipVertically(String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().flipVertically();
    imageCollection.put(destFileName, image);
  }

  @Override
  public void brightness(int intensity, String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().brightness(intensity);
    imageCollection.put(destFileName, image);
  }

  @Override
  public void splitRGB(String fileName, String redFileName, String greenFileName, String blueFileName) {
    visualizeComponent(COMPONENTS.RED, fileName, redFileName);
    visualizeComponent(COMPONENTS.GREEN, fileName, greenFileName);
    visualizeComponent(COMPONENTS.BLUE, fileName, blueFileName);
  }

  @Override
  public void combineRGB(String destFileName, String redFileName, String greenFileName, String blueFileName) {
    Image redImage = imageCollection.get(redFileName);
    Image greenImage = imageCollection.get(greenFileName);
    Image blueImage = imageCollection.get(blueFileName);

    Image image = redImage.cloneImage().combineRGB(greenImage, blueImage);
    imageCollection.put(destFileName, image);

  }

  @Override
  public List<ArrayList<PixelInterface>> getImagePixels(String filename) {
    return imageCollection.get(filename).getPixels();
  }

}
