package View;

/**
 * Given class will contain the methods implemented
 * for user interaction.
 * <p>
 * It will further pass command to controller for handling it.
 * </p>
 */
public class ImageViewImpl implements ImageView {

}
