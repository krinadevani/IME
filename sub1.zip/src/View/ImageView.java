package View;

/**
 * Given Interface will contain summary of the
 * methods used to interact with users.
 */
public interface ImageView {

}
