import Controller.ImageController;
import Controller.ImageControllerImpl;
import Model.ImageModel;
import Model.ImageModelImpl;
import View.ImageView;
import View.ImageViewImpl;

public class SimpleController {

  public static void main(String[] args) {
    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, System.in, System.out);
    controller.go();
  }

}
