package Model;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Given Class represents a PPM image file.
 * <p>
 * Given class performs various processing and manipulations
 * on the PPM file like load, save, clone, flip an image, manage the brightness,
 * create a greyscale image based on value component provided, split and combine
 * an image.
 * It extends abstract class named AbstractImage.
 * </p>
 */
public class PPM extends AbstractImage {

  /**
   * Given constructor will inherit the width, height, maxVal
   * and arraylist of the pixels.
   *
   * @param width  width of the ppm file
   * @param height height of the ppm file
   * @param maxVal maximum value of the ppm file
   * @param pixels arraylist of pixels of the given ppm
   */
  public PPM(int width, int height, int maxVal, ArrayList<ArrayList<PixelInterface>> pixels) {
    super(width, height, maxVal, pixels);
  }

  @Override
  public Image load(String path, String fileName) {
    Scanner sc;
    ArrayList<ArrayList<PixelInterface>> pixels = new ArrayList<ArrayList<PixelInterface>>();
    try {
      sc = new Scanner(new FileInputStream(path));
    } catch (FileNotFoundException e) {
      System.out.println("File " + path + " not found!");
      return null;
    }
    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }
    int width = sc.nextInt();
    int height = sc.nextInt();
    int maxValue = sc.nextInt();

    for (int i = 0; i < height; i++) {
      pixels.add(new ArrayList<PixelInterface>());
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        PixelInterface pixel = new Pixel(r, g, b);
        pixels.get(i).add(j, pixel);
      }
    }
    return new PPM(width, height, maxValue, pixels);
  }

  @Override
  public Image cloneImage() {
    return new PPM(width, height, maxVal, makeCopyOfArray(pixels));
  }

  @Override
  public void saveImage(String path, Image image) throws IOException {
    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(path)));
    writer.write("P3");
    writer.newLine();
    writer.write(image.getWidth() + " " + image.getHeight());
    writer.newLine();
    writer.write(String.valueOf(image.getMaxVal()));
    for (int row = 0; row < image.getHeight(); row++) {
      for (int column = 0; column < image.getWidth(); column++) {
        writer.newLine();
        writer.write(String.valueOf(image.getPixel(row, column).getR()));
        writer.newLine();
        writer.write(String.valueOf(image.getPixel(row, column).getG()));
        writer.newLine();
        writer.write(String.valueOf(image.getPixel(row, column).getB()));
      }
    }
    writer.flush();
    writer.close();
  }

  @Override
  protected Image getImageObject(int width, int height, int maxVal, ArrayList<ArrayList<PixelInterface>> pixels) {
    return new PPM(width, height, maxVal, pixels);
  }

}
