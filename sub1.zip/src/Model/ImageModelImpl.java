package Model;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * Given implementation represents a model class.
 * It contains all the business logic of image processing and manipulation.
 * <p>
 * Given Image model class will contains various image processing logics
 * like load, save image, flip an image, convert it to greyscale image
 * based on various value components, combine and  split image etc.
 * </p>
 * Also, it will use generalised methods from the abstract class.
 */
public class ImageModelImpl implements ImageModel {

  private Image img;
  private final Map<String, Image> imageCollection;
  private final StringBuilder errorLogs;

  /**
   * Given constructor will initialize image collection hashmap
   * and error logs string builder.
   */
  public ImageModelImpl() {
    imageCollection = new HashMap<>();
    this.errorLogs = new StringBuilder();
  }

  @Override
  public void load(String path, String fileName) throws FileNotFoundException, IllegalArgumentException {
    this.img = readImage(path);
    imageCollection.put(fileName, img);
  }

  @Override
  public void save(String path, String fileName) throws IOException {
    img.saveImage(path, imageCollection.get(fileName));
  }

  @Override
  public void visualizeComponent(COMPONENTS component, String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().visualizeComponent(component);
    imageCollection.put(destFileName, image);
  }

  @Override
  public void flipHorizontally(String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().flipHorizontally();
    imageCollection.put(destFileName, image);
  }

  @Override
  public void flipVertically(String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().flipVertically();
    imageCollection.put(destFileName, image);
  }

  @Override
  public void brightness(int intensity, String fileName, String destFileName) {
    Image image = imageCollection.get(fileName).cloneImage().brightness(intensity);
    imageCollection.put(destFileName, image);
  }

  @Override
  public void splitRGB(String fileName, String redFileName, String greenFileName, String blueFileName) {
    visualizeComponent(COMPONENTS.RED, fileName, redFileName);
    visualizeComponent(COMPONENTS.GREEN, fileName, greenFileName);
    visualizeComponent(COMPONENTS.BLUE, fileName, blueFileName);
  }

  @Override
  public void combineRGB(String destFileName, String redFileName, String greenFileName, String blueFileName) {
    Image redImage = imageCollection.get(redFileName);
    Image greenImage = imageCollection.get(greenFileName);
    Image blueImage = imageCollection.get(blueFileName);

    Image image = redImage.cloneImage().combineRGB(greenImage,blueImage);
    imageCollection.put(destFileName, image);

  }


  /**
   * Given method will read the image from the specified path
   * and return a new image object.
   * <p>
   * It reads image in pixels format.
   * Also, save their width, height and maxvalue.
   * </p>
   *
   * @param path file path provided to read the file
   * @return image object create by reading provided file
   */
  private Image readImage(String path) throws FileNotFoundException, IllegalArgumentException {
    Scanner sc;
    ArrayList<ArrayList<PixelInterface>> pixels = new ArrayList<ArrayList<PixelInterface>>();
    try {
      sc = new Scanner(new FileInputStream(path));
    } catch (FileNotFoundException e) {
      throw new FileNotFoundException();
    }

    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (!s.isEmpty() && s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;
    token = sc.next();

    if (!token.equals("P3")) {
      throw new IllegalArgumentException();
    }
    int width = sc.nextInt();
    int height = sc.nextInt();
    int maxValue = sc.nextInt();

    for (int i = 0; i < height; i++) {
      pixels.add(new ArrayList<PixelInterface>());
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        PixelInterface pixel = new Pixel(r, g, b);
        pixels.get(i).add(j, pixel);
      }
    }
    return new PPM(width, height, maxValue, pixels);
  }


  @Override
  public ArrayList<ArrayList<PixelInterface>> getImagePixels(String filename) {
    return imageCollection.get(filename).getPixels();
  }

  @Override
  public String getErrorLogs() {
    return this.errorLogs.toString();
  }
}
