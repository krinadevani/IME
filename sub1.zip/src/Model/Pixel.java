package Model;

/**
 * Given class represents entity class of pixel object.
 * <p>
 * An image is a sequence of pixels.
 * Each pixel has a position in the image and a color.
 * Color of a pixel is represented by breaking it into individual components in R,G,B.
 * </p>
 * It contains get and set method for R, G, B value
 * and get method for value, intensity and luma.
 */
public class Pixel implements PixelInterface {

  private int R, G, B;

  /**
   * Given constructor will initialize the R, G, B values.
   *
   * @param R provided value of red component
   * @param G provided value of green component
   * @param B provided value of blue component
   */
  public Pixel(int R, int G, int B) {
    this.R = R;
    this.G = G;
    this.B = B;
  }

  @Override
  public int getR() {
    return R;
  }

  @Override
  public void setR(int r) {
    R = r;
  }

  @Override
  public int getG() {
    return G;
  }

  @Override
  public void setG(int g) {
    G = g;
  }

  @Override
  public int getB() {
    return B;
  }

  @Override
  public void setB(int b) {
    B = b;
  }

  @Override
  public int getValue() {
    return Math.max(B, (Math.max(R, G)));
  }

  @Override
  public int getIntensity() {
    return (R + G + B) / 3;
  }

  @Override
  public int getLuma() {
    return (int) (0.2126 * R + 0.7152 * G + 0.0722 * B);
  }

}
