import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Scanner;

import Controller.ImageController;
import Controller.ImageControllerImpl;
import Model.Image;
import Model.ImageModel;
import Model.ImageModelImpl;
import Model.PPM;
import Model.Pixel;
import Model.PixelInterface;
import View.ImageView;
import View.ImageViewImpl;

import static org.junit.Assert.*;

public class SimpleControllerTest {


  private ArrayList<ArrayList<PixelInterface>> getImagePixels(String filePath) {
    Scanner sc;
    ArrayList<ArrayList<PixelInterface>> pixels = new ArrayList<ArrayList<PixelInterface>>();
    try {
      sc = new Scanner(new FileInputStream(filePath));
    } catch (FileNotFoundException e) {
      return null;
    }

    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (!s.isEmpty() && s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;
    token = sc.next();


    int width = sc.nextInt();
    int height = sc.nextInt();
    int maxValue = sc.nextInt();

    for (int i = 0; i < height; i++) {
      pixels.add(new ArrayList<PixelInterface>());
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        PixelInterface pixel = new Pixel(r, g, b);
        pixels.get(i).add(j, pixel);
      }
    }
    return pixels;
  }

  private boolean assertPixels(ArrayList<ArrayList<PixelInterface>> storedPixels, ArrayList<ArrayList<PixelInterface>> originalImagePixels) {
    if (originalImagePixels == null) {
      return false;
    }
    for (int i = 0; i < originalImagePixels.size(); i++) {
      for (int j = 0; j < originalImagePixels.get(0).size(); j++) {
        int r = originalImagePixels.get(i).get(j).getR();
        int g = originalImagePixels.get(i).get(j).getG();
        int b = originalImagePixels.get(i).get(j).getB();
        if (r != storedPixels.get(i).get(j).getR() || g != storedPixels.get(i).get(j).getG() && b != storedPixels.get(i).get(j).getB()) {
          return false;
        }
      }
    }
    return (originalImagePixels.size() == storedPixels.size());
  }

  private boolean assertImage(ArrayList<ArrayList<PixelInterface>> storedPixels, String path) {
    ArrayList<ArrayList<PixelInterface>> originalImagePixels = getImagePixels(path);
    return assertPixels(storedPixels, originalImagePixels);
  }

  private boolean assertImageFiles(String originalImagePath, String savedImagePath) throws IOException {
    ArrayList<ArrayList<PixelInterface>> originalImagePixels = getImagePixels(originalImagePath);
    ArrayList<ArrayList<PixelInterface>> savedImagePixels = getImagePixels(savedImagePath);

    return assertPixels(savedImagePixels, originalImagePixels);
  }

  @Test
  public void loadImage() {

    String input = "load test/images/owl.ppm owl\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());


    OutputStream out = new ByteArrayOutputStream();

    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    ArrayList<ArrayList<PixelInterface>> pixels = model.getImagePixels("owl");
    assertTrue(assertImage(pixels, "test/images/owl.ppm"));


  }

  @Test
  public void loadSaveImage() throws IOException {

    String input = "load res/owl.ppm owl\r\nsave test/images/owl.ppm owl\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl.ppm", "test/images/owl.ppm"));

  }

  @Test
  public void loadBrightenSaveImage() throws IOException {
    String input = "load res/owl.ppm owl\r\nbrighten 10 owl owl-brighter\r\nsave test/images/owl-brighter.ppm owl-brighter\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-brighter.ppm", "test/images/owl-brighter.ppm"));
  }

  @Test
  public void loadDarkenSaveImage() throws IOException {
    String input = "load res/owl.ppm owl\r\nbrighten -50 owl owl-darken\r\nsave test/images/owl-darken.ppm owl-darken\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-darken.ppm", "test/images/owl-darken.ppm"));
  }

  @Test
  public void loadVerticalFlipSaveImage() throws IOException {
    String input = "load res/owl.ppm owl\r\nvertical-flip owl owl-vertical\r\nsave test/images/owl-vertical.ppm owl-vertical\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-vertical.ppm", "test/images/owl-vertical.ppm"));
  }

  @Test
  public void loadHorizontalFlipSaveImage() throws IOException {
    String input = "load res/owl.ppm owl\r\nhorizontal-flip owl owl-horizontal\r\nsave test/images/owl-horizontal.ppm owl-horizontal\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-horizontal.ppm", "test/images/owl-horizontal.ppm"));
  }

  @Test
  public void greyscaleRedImage() throws IOException {
    String input = "load res/owl.ppm owl\r\ngreyscale red-component owl owl-red\r\nsave test/images/owl-red.ppm owl-red\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-red.ppm", "test/images/owl-red.ppm"));
  }

  @Test
  public void greyscaleGreenImage() throws IOException {
    String input = "load res/owl.ppm owl\r\ngreyscale green-component owl owl-green\r\nsave test/images/owl-green.ppm owl-green\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-green.ppm", "test/images/owl-green.ppm"));
  }

  @Test
  public void greyscaleBlueImage() throws IOException {
    String input = "load res/owl.ppm owl\r\ngreyscale blue-component owl owl-blue\r\nsave test/images/owl-blue.ppm owl-blue\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-blue.ppm", "test/images/owl-blue.ppm"));
  }

  @Test
  public void greyscaleValueImage() throws IOException {
    String input = "load res/owl.ppm owl\r\ngreyscale value-component owl owl-greyscale-value\r\nsave test/images/owl-greyscale-value.ppm owl-greyscale-value\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-greyscale-value.ppm", "test/images/owl-greyscale-value.ppm"));
  }

  @Test
  public void greyscaleLumaImage() throws IOException {
    String input = "load res/owl.ppm owl\r\ngreyscale luma-component owl owl-greyscale-luma\r\nsave test/images/owl-greyscale-luma.ppm owl-greyscale-luma\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-greyscale-luma.ppm", "test/images/owl-greyscale-luma.ppm"));
  }

  @Test
  public void greyscaleIntensityImage() throws IOException {
    String input = "load res/owl.ppm owl\r\ngreyscale intensity-component owl owl-greyscale-intensity\r\nsave test/images/owl-greyscale-intensity.ppm owl-greyscale-intensity\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-greyscale-intensity.ppm", "test/images/owl-greyscale-intensity.ppm"));
  }

  @Test
  public void rgbSplitImage() throws IOException {
    String input = "load res/owl.ppm owl\r\nrgb-split owl owl-red owl-green owl-blue"
            + "\r\nsave test/images/owl-red.ppm owl-red\n" +
            "save test/images/owl-green.ppm owl-green\n" +
            "save test/images/owl-blue.ppm owl-blue\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-red.ppm", "test/images/owl-red.ppm"));
    assertTrue(assertImageFiles("res/owl-green.ppm", "test/images/owl-green.ppm"));
    assertTrue(assertImageFiles("res/owl-blue.ppm", "test/images/owl-blue.ppm"));
  }

  @Test
  public void rgbCombine() throws IOException {
    String input = "load res/owl.ppm owl\r\nrgb-split owl owl-red owl-green owl-blue"
            + "\r\nrgb-combine owl-red-tint owl-red owl-green owl-blue\r\nsave test/images/owl-red-tint.ppm owl-red-tint\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();

    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertTrue(assertImageFiles("res/owl-red-tint.ppm", "test/images/owl-red-tint.ppm"));
  }

  @Test
  public void fileNameNotStored() {
    //owl-horizontal is not stored anywhere in the program so it will return error while saving the image.
    String input = "load res/owl.ppm owl\r\nvertical-flip owl owl-vertical\r\nsave test/images/owl-vertical.ppm owl-horizontal\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();

    assertEquals("Filename passed is not loaded :save test/images/owl-vertical.ppm owl-horizontal\n" + System.lineSeparator(), out.toString());
  }

  @Test
  public void invalidCommandName() {
    //owl-horizontal is not stored anywhere in the program so it will return error while saving the image.
    String input = "loaded res/owl.ppm owl";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();


    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();

    assertEquals("Invalid command name passed :loaded res/owl.ppm owl\n" + System.lineSeparator(), out.toString());
  }

  @Test
  public void multipleSpaceInCommand() {

    String input = "load          test/images/owl.ppm       owl\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();

    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    ArrayList<ArrayList<PixelInterface>> pixels = model.getImagePixels("owl");
    assertTrue(assertImage(pixels, "test/images/owl.ppm"));
  }

  @Test
  public void moreParametersInCommand() {

    String input = "load test/images/owl.ppm owl koala\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();

    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertEquals("Invalid arguments passed :load test/images/owl.ppm owl koala\n"
            + System.lineSeparator(),out.toString());
  }

  @Test
  public void onlyCommandPassed() {

    String input = "load\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();

    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertEquals("Invalid arguments passed :load\n"
            + System.lineSeparator(),out.toString());
  }

  @Test
  public void imageDontExistOnPath() {

    String input = "load test/images/koala.ppm owl\r\nexit";
    InputStream in = new ByteArrayInputStream(input.getBytes());
    OutputStream out = new ByteArrayOutputStream();

    ImageModel model = new ImageModelImpl();
    ImageView view = new ImageViewImpl();
    ImageController controller = new ImageControllerImpl(model, view, in, out);
    controller.go();
    assertEquals("File not found :load test/images/koala.ppm owl\n"
            + System.lineSeparator(),out.toString());
  }

}